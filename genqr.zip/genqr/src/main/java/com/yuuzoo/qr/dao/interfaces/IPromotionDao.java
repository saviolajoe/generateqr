package com.yuuzoo.qr.dao.interfaces;

import com.yuuzoo.qr.model.PromotionMod;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
public interface IPromotionDao {

    public int countUser() throws Exception;
    public PromotionMod getPromotion() throws Exception;
    public String getIPAddress(final String ipAddress) throws Exception;
    public boolean update(final int promotionId, final String ipAddress) throws Exception;

}
