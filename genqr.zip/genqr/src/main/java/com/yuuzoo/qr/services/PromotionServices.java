package com.yuuzoo.qr.services;

import com.yuuzoo.qr.dao.interfaces.IPromotionDao;
import com.yuuzoo.qr.model.PromotionMod;
import com.yuuzoo.qr.services.interfaces.IPromotionServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
@Service
public class PromotionServices implements IPromotionServices {

    @Autowired
    private IPromotionDao promotionDao;

    @Override
    public int countUser() throws Exception {
        return this.promotionDao.countUser();
    }

    @Override
    public PromotionMod getPromotion() throws Exception {
        return this.promotionDao.getPromotion();
    }

    @Override
    public String getIpAddress(String ipAddress) throws Exception {
        return this.promotionDao.getIPAddress(ipAddress);
    }

    @Override
    public boolean update(final int promotionId, String ipAddress) throws Exception {
        return this.promotionDao.update(promotionId, ipAddress);
    }
}
