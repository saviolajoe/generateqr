package com.yuuzoo.qr.dao;

import com.yuuzoo.qr.dao.interfaces.IPromotionDao;
import com.yuuzoo.qr.model.PromotionMod;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
@Repository
public class PromotionDao extends NamedParameterJdbcDaoSupport implements IPromotionDao {

    public void initDao(){
    }

    @Override
    public int countUser() throws Exception {
        String sql = "SELECT count(*) as cnt FROM tb_promotion_use";
        return super.getJdbcTemplate().query(sql, new ResultSetExtractor<Integer>() {

            @Override
            public Integer extractData(ResultSet rs) throws SQLException,
                    DataAccessException {
                if (rs.next()) {
                    return rs.getInt("cnt");
                }

                return 0;
            }
        });
    }

    @Override
    public PromotionMod getPromotion() throws Exception {
        String sql = "SELECT * FROM tb_promotion";
        return super.getJdbcTemplate().query(sql, new ResultSetExtractor<PromotionMod>() {

            @Override
            public PromotionMod extractData(ResultSet rs) throws SQLException,
                    DataAccessException {
                if (rs.next()) {
                    PromotionMod mod = new PromotionMod();
                    mod.setId(rs.getInt("id"));
                    mod.setUserLimit(rs.getInt("user_limit"));
                    return mod;
                }

                return null;
            }
        });
    }

    @Override
    public String getIPAddress(String ipAddress) throws Exception {
        String sql = "SELECT ip_address FROM tb_promotion_use WHERE ip_address='" + ipAddress + "'";
        return super.getJdbcTemplate().query(sql, new ResultSetExtractor<String>() {

            @Override
            public String extractData(ResultSet rs) throws SQLException,
                    DataAccessException {
                if (rs.next()) {
                    return rs.getString("ip_address");
                }

                return null;
            }

        });
    }

    @Override
    public boolean update(final int promotionId, final String ipAddress) throws Exception {
        String sql = "insert into tb_promotion_use (promotion_id, ip_address, updated_date) values(?, ?, ?)";
        super.getJdbcTemplate().update(sql, promotionId, ipAddress, new Date());
        return true;
    }
}
