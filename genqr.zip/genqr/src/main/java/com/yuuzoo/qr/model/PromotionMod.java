package com.yuuzoo.qr.model;

import java.io.Serializable;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
public class PromotionMod implements Serializable {

    private int id;
    private int userLimit;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserLimit() {
        return userLimit;
    }

    public void setUserLimit(int userLimit) {
        this.userLimit = userLimit;
    }
}
