package com.yuuzoo.qr.services.interfaces;

import com.yuuzoo.qr.model.PromotionMod;
import org.springframework.stereotype.Service;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
public interface IPromotionServices {

    public int countUser() throws Exception;
    public PromotionMod getPromotion() throws Exception;
    public String getIpAddress(final String ipAddress) throws Exception;

    public boolean update(final int promotionId, final String ipAddress) throws Exception;

}
