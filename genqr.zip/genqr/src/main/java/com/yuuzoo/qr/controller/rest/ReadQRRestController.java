package com.yuuzoo.qr.controller.rest;

import com.yuuzoo.qr.model.PromotionMod;
import com.yuuzoo.qr.services.interfaces.IPromotionServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by saviola.joe on 7/19/2017 AD.
 */
@RestController
@RequestMapping("/rest")
public class ReadQRRestController {

    @Autowired
    private IPromotionServices promotionServices;

    @RequestMapping
    public ModelAndView readQR(HttpServletRequest request){
        String ipAddress = getClientIp(request);
        ModelAndView model = new ModelAndView("view");
        try {
            PromotionMod mod = this.promotionServices.getPromotion();
            int cnt = this.promotionServices.countUser();
            if(mod.getUserLimit()>cnt){
                String ip = this.promotionServices.getIpAddress(ipAddress);
                if (ip != null && ip.length() > 0) {
                    model.addObject("msg", "You have already received a discount.");
                } else {
                    boolean bool = this.promotionServices.update(mod.getId(), ipAddress);
                    if(bool){
                        model.addObject("msg", "You get discount 10%, Thank you.");
                    }else{
                        model.addObject("msg", "You can't get discount 10%");
                    }
                }
            }else{
                model.addObject("msg", "This Promotion has quota "+mod.getUserLimit()+",<br>This promotion has already expired.");
            }
        }catch (Exception e){
            model.addObject("msg", e.getMessage());
        }
        return model;
    }

    private String getClientIp(HttpServletRequest request) {

        String remoteAddr = "";

        if (request != null) {
            remoteAddr = request.getHeader("X-FORWARDED-FOR");
            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = request.getRemoteAddr();
            }
        }

        return remoteAddr;
    }

}
